package Projet.Biblio.User;

import java.time.LocalDate;

import javafx.beans.property.*;

/**
 * Model class for a Person.
 *
 * @author Marco Jakob
 */
public class Person {

    private final StringProperty firstName;
    private final StringProperty lastName;
    private final IntegerProperty nbremprunt;
    private final StringProperty livrenonrendu;
    private final ObjectProperty<LocalDate> birthday;

    /**
     * Default constructor.
     */
    public Person() {
        this(null, null);
    }

    /**
     * Constructor with some initial data.
     *
     * @param firstName
     * @param lastName
     */
    public Person(String firstName, String lastName) {
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);

        // Some initial dummy data, just for convenient testing.
        this.nbremprunt = new SimpleIntegerProperty(1234);
        this.livrenonrendu = new SimpleStringProperty("some livrenonrendu");
        this.birthday = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
    }

    public String getFirstName() {
        return firstName.get();
    }

    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }

    public StringProperty firstNameProperty() {
        return firstName;
    }

    public String getLastName() {
        return lastName.get();
    }

    public void setLastName(String lastName) {
        this.lastName.set(lastName);
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public int getnbremprunt() {
        return nbremprunt.get();
    }

    public void setnbremprunt(int nbremprunt) {
        this.nbremprunt.set(nbremprunt);
    }

    public IntegerProperty nbrempruntProperty() {
        return nbremprunt;
    }

    public String getlivrenonrendu() {
        return livrenonrendu.get();
    }

    public void setlivrenonrendu(String livrenonrendu) {
        this.livrenonrendu.set(livrenonrendu);
    }

    public StringProperty livrenonrenduProperty() {
        return livrenonrendu;
    }

    public LocalDate getBirthday() {
        return birthday.get();
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday.set(birthday);
    }

    public ObjectProperty<LocalDate> birthdayProperty() {
        return birthday;
    }
}